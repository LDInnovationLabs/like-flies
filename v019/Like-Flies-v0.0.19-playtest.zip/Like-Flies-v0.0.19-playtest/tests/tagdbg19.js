const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const url = 'http://127.0.0.1:8080/index.html?peerhost=127.0.0.1:9000&room=td' + Date.now() % 100000;
  const mk = async n => { const p = await (await b.newContext({viewport:{width:200, height:140}})).newPage(); p.on('pageerror', e => console.log(n, 'ERR', e.message)); await p.goto(url, {timeout:90000}); await p.fill('#mpName', n); await p.dispatchEvent('#mpName', 'input'); return p; };
  const A = await mk('Job'); await A.waitForTimeout(5000); const B = await mk('Sage');
  for (let i = 0; i < 40; i++){ if (await B.evaluate(() => window.__likeflies.net.remotes.size >= 1)) break; await B.waitForTimeout(1000); }
  for (const p of [A, B]){ await p.click('#flatBtn'); await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; }); }
  const put = (p, pt) => p.evaluate(pt => { const L = window.__likeflies, V = THREE.Vector3, h = new V(); L.game.crawl = null; L.game.level = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); L.camera.getWorldPosition(h); L.rig.position.add(new V(pt[0] - h.x, pt[1] - h.y, pt[2] - h.z)); }, pt);
  await put(A, [20, 8, 30]); await put(B, [22, 8, 30]);
  await A.evaluate(() => window.__likeflies.act.join()); await B.evaluate(() => window.__likeflies.act.join()); await A.waitForTimeout(4000);
  await put(B, [20, 8, 30]); await A.waitForTimeout(2500);
  console.log(JSON.stringify(await A.evaluate(() => { const L = window.__likeflies, a = L.act, A = a.ACT, T = A.snap.tag, now = L.now(); const pids = Object.keys(T.mem);
    const elig = pids.map(p => { const j = [...A.slotPid].find(([, q]) => q === p); const r = j ? L.net.remotes.get(j[0]) : null; return {p:p.slice(-5), me:p === L.race.pid(), slot:j && j[0], hasRemote:!!r, kind:r && r.kind, on:r && r.on, out:r && r.out, dd:r && r.dd, age:r && +(now - r.recv).toFixed(2), buf:(A.poses.get(p) || []).map(s => [+(now - s.t).toFixed(2), +s.x.toFixed(2), +s.z.toFixed(2)]).slice(-4)}; });
    const other = pids.find(p => p !== T.it); const sw = other ? a.swept(T.it, other, now, 0.25) : null;
    return {isHost:a.isHost(), slotPid:[...A.slotPid].map(([j, p]) => [j, p.slice(-5)]), me:L.race.pid().slice(-5), it:T.it && T.it.slice(-5), rdyIn:+(A.host.rdyUntil - now).toFixed(2), joinT:Object.fromEntries(Object.entries(A.host.joinT).map(([k, v]) => [k.slice(-5), +(now - v).toFixed(1)])), elig, sw:sw && {d:String(sw.d), stale:sw.stale, a:sw.a, b:sw.b}, reach:other ? a.reach(T.it, other) : null, myElig:L.game.role + ' ' + L.game.out + ' ' + L.game.deadUntil, events:A.events.slice(-6)}; }), null, 0));
  await b.close(); })();
