// shared helpers for v0.0.16 race tests: they move the real fly rig through real frames; the game's own per-frame
// crossing detector, state machine and room ledger do all the work.
exports.helpers = (p) => {
  const H = {};
  H.frames = (n) => p.evaluate(n => new Promise(res => { let k = 0; const f = () => { if (++k >= n) res(); else requestAnimationFrame(f); }; requestAnimationFrame(f); }), n || 2);
  // put the fly's head at a world point (the rig follows), then let the game run frames there
  H.at = async (pt, n) => { await p.evaluate(pt => { const L = window.__likeflies, V = THREE.Vector3; L.game.crawl = null; L.game.level = null; L.game.stuck = null; L.game.stickCool = 1e12;
      L.tune().gravity = 0; L.rig.updateMatrixWorld(true); const h = new V(); L.camera.getWorldPosition(h); L.rig.position.add(new V(pt[0] - h.x, pt[1] - h.y, pt[2] - h.z)); L.rig.updateMatrixWorld(true); }, pt); await H.frames(n || 2); };
  H.course = () => p.evaluate(() => window.__likeflies.race.course());
  H.state = () => p.evaluate(() => window.__likeflies.race.state());
  H.ledger = () => p.evaluate(() => window.__likeflies.race.ledger());
  // fly straight through ring i along its normal (dir = +1 or -1), in steps no longer than step units
  H.through = async (i, dir, opts) => { const o = Object.assign({d:4, step:1.6, off:[0, 0]}, opts || {}), C = await H.course(), r = C[i], n = r.n.map(v => v * (dir || 1));
    let u = [n[1], -n[0], 0]; const ul = Math.hypot(...u); if (ul < 1e-3) u = [1, 0, 0]; else u = u.map(v => v / ul); const w = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]];
    const base = r.c.map((v, k) => v + u[k] * o.off[0] + w[k] * o.off[1]);
    for (let t = -o.d; t <= o.d + 1e-9; t += o.step) await H.at(base.map((v, k) => v + n[k] * t), o.n || 1); };
  // fly the whole circuit from the armed start: through each next ring in order
  H.lap = async (opts) => { const st = await H.state(), C = await H.course(), N = C.length; for (let k = 0; k < N; k++){ const i = (st.start + k) % N; if (opts && opts.beforeEach) await opts.beforeEach(k); await H.through(i, 1, opts); if (opts && opts.beforeLast && k === N - 2) await opts.beforeLast(); } };
  H.armAt = async (i) => { const C = await H.course(), r = C[i]; await H.at(r.c.map((v, k) => v + r.n[k] * 6)); await p.keyboard.press('KeyT'); await H.frames(2); };
  return H;
};
