#!/usr/bin/env python3
# v0.0.19 integration: Backyard activities (Buzz Tag, Hide-a-Crumb, Ghost Wings, Backyard Field Guide) on top of v0.0.18b.
SP = '/tmp/claude-0/-home-claude/bc728752-7522-5400-ba10-22130a4e22ce/scratchpad/'
p = '/home/claude/like-flies.html'
s = open(p).read()
def rep(a, b, count=1):
    global s
    n = s.count(a)
    assert n == count, (n, a[:100])
    s = s.replace(a, b)

# labels
rep('<div class="eyebrow">Test v0.0.18b · Fly feet</div>', '<div class="eyebrow">Test v0.0.19 · Backyard activities</div>')
rep("c.fillText('v0.0.18b · ' + inputMode, PW - 30, 60);", "c.fillText('v0.0.19 · ' + inputMode, PW - 30, 60);")
rep("const lines = ['Like Flies v0.0.18 settings']", "const lines = ['Like Flies v0.0.19 settings']")

# pages: Activities tab, labels fitted to the tab width
rep("const PAGES = ['Flight', 'Powered glide', 'Crawl', 'Combat', 'Carry', 'Game', 'Play', 'Race', 'Retro', 'VHS'];",
    "const PAGES = ['Activities', 'Flight', 'Powered glide', 'Crawl', 'Combat', 'Carry', 'Game', 'Play', 'Race', 'Retro', 'VHS'];")
rep("c.font = 'bold ' + (PAGES.length > 8 ? 18 : 23) + 'px system-ui, sans-serif'; c.fillText(TAB_LABEL[pg] || pg, x + tw/2, TAB_Y + 35);",
    "{ const lab = TAB_LABEL[pg] || pg; let fsz = PAGES.length > 8 ? 18 : 23; c.font = 'bold ' + fsz + 'px system-ui, sans-serif'; while (fsz > 11 && c.measureText(lab).width > tw - 6){ fsz--; c.font = 'bold ' + fsz + 'px system-ui, sans-serif'; } c.fillText(lab, x + tw/2, TAB_Y + 35); }")
rep("  if (panelPage === 'Race'){   // v0.0.16: the room race board in the headset",
    "  if (panelPage === 'Activities') actDrawPanel(c);   // v0.0.19: four activity cards with big buttons\n  if (panelPage === 'Race'){   // v0.0.16: the room race board in the headset")
rep("    const off = panelPage === 'Game' ? 1 : 0;\n    if (off && py >= ROW0 && py < ROW0 + ROW){",
    "    if (panelPage === 'Activities' && py >= ROW0 - 8 && py < TOG_Y){ actPanelPress(px, py); drawPanel(); return; }\n    const off = panelPage === 'Game' ? 1 : 0;\n    if (off && py >= ROW0 && py < ROW0 + ROW){")

# page menu: Activities section and its styles
rep('    <details id="raceBox" open>',
    '    <details id="actBox" open>\n      <summary>Activities</summary>\n      <div id="actBody"></div>\n    </details>\n\n    <details id="raceBox" open>')
rep("</style>", ".actcard{border:1px solid rgba(127,227,214,.25);border-radius:12px;padding:10px 12px;margin:8px 0;background:rgba(238,245,234,.04)}.actcard p{margin:4px 0}.actcard small{display:block;opacity:.75}"
    ".actcard textarea{width:100%;box-sizing:border-box;margin-top:6px;font:12px ui-monospace,monospace}.journal{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}.jentry{width:120px;font-size:12px;opacity:.6}.jentry.on{opacity:1}.jentry canvas{display:block;background:rgba(0,0,0,.15);border-radius:8px}\n</style>", 1)

# HUD: one activity line, only for what you are doing
rep("    game.hudCarry ? game.hudCarry + ' · ' + raceLine : raceLine,",
    "    [game.hudCarry, actHudLine(clock.elapsedTime), raceLine].filter(Boolean).join(' · '),")

# race: Tag suspends automatic race starts; ghosts launch at the first accepted gate; finished laps can become ghosts
rep("  else if (race.phase === 'off') raceArm('back in the race');",
    "  else if (race.phase === 'off' && !(actInTag() || ACT.wantTag)) raceArm('back in the race');   // v0.0.19: no automatic race starts while in Buzz Tag")
rep("    raceLog({k:'start', ring:i, runId:race.runId}); retroBurst(0.35);", "    raceLog({k:'start', ring:i, runId:race.runId}); retroBurst(0.35); ghostOnRaceStart();")
rep("  updateRaceBoard();\n}\nfunction raceTick(){", "  ghostOnFinish(race.result);   // v0.0.19: Ghost Wings keeps your best line per start ring\n  updateRaceBoard();\n}\nfunction raceTick(){")

# networking: hello, snapshot to new connections, routed messages, dead flag, pose samples for Tag
rep("    sendState(true); sendTuneSnapshot(conn); sendLedger(conn);", "    sendState(true); sendTuneSnapshot(conn); sendLedger(conn); actOnConnOpen(conn);")
rep("    else if (d.t === 'rs') onRaceSubmit(j, d); else if (d.t === 'rl') onLedger(j, d); });",
    "    else if (d.t === 'rs') onRaceSubmit(j, d); else if (d.t === 'rl') onLedger(j, d);\n    else if (d.t === 'ah' || d.t === 'as' || d.t === 'aq' || d.t === 'gq' || d.t === 'gc' || d.t === 'gn') actOnMessage(j, d); });   // v0.0.19: activities")
rep("Object.assign(msg, {lv:game.lives, hpt:game.hp,", "Object.assign(msg, {dd:game.deadUntil > nw ? 1 : 0, lv:game.lives, hpt:game.hp,")
rep("    r.lkT = Array.isArray(d.lk)", "    r.dd = d.dd ? 1 : 0; if (typeof actPushPose === 'function') actPushPose(ACT.slotPid.get(j), clock.elapsedTime, r.tgt);   // v0.0.19: recent poses for Buzz Tag\n    r.lkT = Array.isArray(d.lk)")
rep("  if (typeof ledgerReset === 'function'){ ledgerReset();", "  if (typeof actRoomReset === 'function') actRoomReset();\n  if (typeof ledgerReset === 'function'){ ledgerReset();")

# per frame
rep("  raceTick(); animateRings(t);", "  raceTick(); animateRings(t); actTick(dt, t);")

# the module itself, plus hooks for checks
act = open(SP + 'act19.js').read()
rep("window.__likeflies = {fly18:{", act + "\nwindow.__likeflies = {act:{ACT, store:actStore, ghosts:ghostStore, GUIDE, tick:actTick, apply:actApply, onMsg:actOnMessage, swept:actSwept, reach:actReach, check:actCheckPlace, exportCode:actExportCode, importCode:actImportCode, cards:actCards, panelPress:actPanelPress, join:actTagJoin, leave:actTagLeave, crumbStart:actCrumbStart, crumbConfirm:actCrumbConfirm, search:actCrumbSearch, ghostWatch, ghostValid, ghostPlay, ghostStop, ghostOnMsg:ghostOnMessage, pushPose:actPushPose, isHost:actIsHost, world:ACT_WORLD}, fly18:{")
open(p, 'w').write(s)
print('ok')
