const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']}); const p = await b.newPage({viewport:{width:640, height:420}});
  await p.goto('http://127.0.0.1:8080/index.html', {timeout:90000}); await p.waitForTimeout(7000); await p.click('#flatBtn'); await p.waitForTimeout(1000);
  await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; window.__likeflies.act.store.scan = true; });
  const c0 = await p.evaluate(() => window.__likeflies.act.ACT.guideT.duck.bc.toArray()); await p.waitForTimeout(2500); const c1 = await p.evaluate(() => window.__likeflies.act.ACT.guideT.duck.bc.toArray());
  const moved = Math.hypot(c0[0] - c1[0], c0[1] - c1[1], c0[2] - c1[2]);
  // look at the pool water away from the duck: no scan; then at the duck: scan
  const aim = (pos, tgt) => p.evaluate(([pos, tgt]) => { const L = window.__likeflies, V = THREE.Vector3; L.game.crawl = null; L.game.level = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); const h = new V(); L.camera.getWorldPosition(h); L.rig.position.add(new V(...pos).sub(h)); const d = new V(...tgt).sub(new V(...pos)); L.setLook(Math.atan2(-d.x, -d.z), Math.atan2(d.y, Math.hypot(d.x, d.z))); }, [pos, tgt]);
  const pool = await p.evaluate(() => { const s = window.__likeflies.solids.find(s => s.label === 'the kiddie pool'); return s.bc.toArray(); });
  const eye = [c1[0] + 10, c1[1] + 6, c1[2] + 10]; const dir = [c1[0] - eye[0], c1[1] - eye[1], c1[2] - eye[2]];
  const water = [pool[0] - (c1[0] - pool[0]) * 1.4, 3.9, pool[2] - (c1[2] - pool[2]) * 1.4];
  await aim(eye, water); await p.waitForTimeout(4000); const w = await p.evaluate(() => ({t:window.__likeflies.act.ACT.scanTgt, got:!!window.__likeflies.act.store.guide.duck}));
  let got = false; for (let k = 0; k < 30 && !got; k++){ const c = await p.evaluate(() => window.__likeflies.act.ACT.guideT.duck.bc.toArray()); await aim(eye, c); await p.waitForTimeout(300); got = await p.evaluate(() => !!window.__likeflies.act.store.guide.duck); if (k === 5) await p.screenshot({path:__dirname + '/s19/guide_1_scanning_duck.png'}); }
  console.log((moved > 0.05 ? 'PASS' : 'FAIL') + ' the duck target follows the live duck  moved ' + moved.toFixed(3) + ' in 2.5 s');
  console.log((!w.got && w.t !== 'duck' ? 'PASS' : 'FAIL') + ' looking at the pool water (not the duck) does not scan the duck  ' + JSON.stringify(w));
  console.log((got ? 'PASS' : 'FAIL') + ' looking at the duck scans it'); await b.close(); })();
