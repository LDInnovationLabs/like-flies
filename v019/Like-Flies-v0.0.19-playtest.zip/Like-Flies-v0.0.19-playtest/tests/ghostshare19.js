// v0.0.19 Ghost Wings sharing over a REAL local peer connection (two desktop browsers): Sage flies a ranked room-record
// lap; Job asks for the record ghost. Sharing off: refused with a clear note. Sharing on: arrives in bounded chunks,
// validates, and plays when Job races from the same start ring. Malformed chunks are fed directly (synthetic) and rejected.
const { chromium } = require('playwright'); const fs = require('fs'); const { helpers } = require('./racelib16.js');
(async () => {
  const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const url = 'http://127.0.0.1:8080/index.html?peerhost=127.0.0.1:9000&room=gs' + Date.now() % 100000, D = __dirname + '/s19/', T0 = Date.now();
  const out = [], ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : '') + '  [' + Math.round((Date.now() - T0) / 1000) + 's]'; out.push(l); console.log(l); };
  const errs = [];
  const mk = async (n, w, h) => { const p = await (await b.newContext({viewport:{width:w, height:h}})).newPage(); p.on('pageerror', e => errs.push(n + ': ' + e.message)); await p.goto(url, {timeout:90000}); await p.fill('#mpName', n); await p.dispatchEvent('#mpName', 'input'); p.H = helpers(p); return p; };
  const until = async (p, fn, arg, ms) => { for (let t = 0; t < ms; t += 400){ if (await p.evaluate(fn, arg)) return true; await p.waitForTimeout(400); } return false; };
  const A = await mk('Job', 640, 420); await A.waitForTimeout(5000); const B = await mk('Sage', 220, 150);
  await until(B, () => window.__likeflies.net.remotes.size >= 1, null, 60000);
  for (const p of [A, B]){ await p.click('#flatBtn'); }
  await A.evaluate(() => { const t = window.__likeflies.tune(); t.bots = 0; t.rtOn = 0; document.querySelector('#t_gravity').value = 0; document.querySelector('#t_gravity').dispatchEvent(new Event('input')); document.querySelector('#t_bots').value = 0; document.querySelector('#t_bots').dispatchEvent(new Event('input')); document.querySelector('#tShare').click(); });
  await until(B, () => window.__likeflies.shareState.rev > 0 && window.__likeflies.race.compSig() === window.__likeflies.race.localSig(), null, 15000);
  await B.evaluate(() => { window.__likeflies.tune().rtOn = 0; });
  // Sage flies a ranked lap from ring 4
  await B.H.armAt(4); await B.H.lap({d:3, step:2, n:1});
  const rec = await until(B, () => { const r = window.__likeflies.race.state().result; return r && r.status === 'record'; }, null, 20000);
  const bg = await B.evaluate(() => Object.values(window.__likeflies.act.ghosts).map(g => ({k:g.k, cs:g.cs, n:g.s.length})));
  ok('Sage sets the room record and keeps a ghost of it', rec && bg.length === 1, JSON.stringify(bg));
  // Job wants the room record ghost; Sage has not opted in
  await A.evaluate(() => { const a = window.__likeflies.act; a.store.ghostMode = 'room'; a.ACT.gqT = -99; });
  const refused = await until(A, () => /not shared/.test(window.__likeflies.act.ACT.ghostWhy), null, 15000);
  ok('no consent: no replay is sent, Job sees "ghost not shared"', refused && (await A.evaluate(() => window.__likeflies.act.ACT.shared.size)) === 0, await A.evaluate(() => window.__likeflies.act.ACT.ghostWhy));
  await B.evaluate(() => { window.__likeflies.act.store.share = true; });
  await A.evaluate(() => { window.__likeflies.act.ACT.gqT = -99; });
  const got = await until(A, () => window.__likeflies.act.ACT.shared.size === 1, null, 20000);
  const ev = await A.evaluate(() => window.__likeflies.act.ACT.events.filter(e => /ghost/.test(e.k)));
  ok('with consent the record ghost arrives in bounded chunks and validates', got, JSON.stringify(ev));
  // Job races from the same start ring: the shared ghost plays; it is never a player or a collider
  await A.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; });
  await A.H.armAt(4); await A.H.through(4, 1, {d:3, step:2, n:1});
  const gl = await A.evaluate(() => { const a = window.__likeflies.act.ACT; return {on:!!a.ghost, label:a.ghost && a.ghost.label, remotes:window.__likeflies.net.remotes.size}; });
  await A.H.through(5, 1, {d:3, step:2, n:1}); await A.H.frames(2);
  const gv = await A.evaluate(() => { let gp = null; window.__likeflies.scene.traverse(o => { if (!gp && o.isGroup && o.userData.w && o.visible) gp = o.position.toArray(); }); return gp; });
  if (gv){ await A.evaluate(gv => { const L = window.__likeflies, V = THREE.Vector3, pos = new V(gv[0] + 1.4, gv[1] + 0.5, gv[2] + 1.4); L.game.crawl = null; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); const h = new V(); L.camera.getWorldPosition(h); L.rig.position.add(pos.clone().sub(h)); const d = new V(...gv).sub(pos); L.setLook(Math.atan2(-d.x, -d.z), Math.atan2(d.y, Math.hypot(d.x, d.z))); }, gv); await A.H.frames(3); await A.screenshot({path:D + 'ghost_2_shared_record_in_race.png'}); }
  ok('Job races from ring 5: the shared record ghost plays (still just one other player in the room)', gl.on && gl.label === 'Room record' && gl.remotes === 1 && !!gv, JSON.stringify(gl));
  // Off removes it
  await A.evaluate(() => { window.__likeflies.act.cards(0)[2].btns[0][1](); });
  ok('Ghost Off removes the ghost at once', await A.evaluate(() => !window.__likeflies.act.ACT.ghost));
  // malformed shared replays (synthetic chunks fed straight into the receive function)
  const bad = await A.evaluate(() => { const a = window.__likeflies.act, A = a.ACT, r = [];
    A.gq = {rid:'t1', run:'r1', from:2, parts:[], n:0}; a.ghostOnMsg(2, {t:'gc', rid:'t1', i:0, n:1, d:'{"v":1,"s":[[0,0,0,0,0]]}'}); r.push(A.ghostWhy);
    A.gq = {rid:'t2', run:'r2', from:2, parts:[], n:0}; a.ghostOnMsg(2, {t:'gc', rid:'t2', i:0, n:1, d:'x'.repeat(9000)}); r.push(A.gq ? 'oversize chunk ignored' : 'accepted?');
    A.gq = {rid:'t3', run:'r3', from:2, parts:[], n:0}; a.ghostOnMsg(2, {t:'gc', rid:'t3', i:0, n:50, d:'{}'}); r.push(A.gq && A.gq.n === 0 ? 'too many chunks ignored' : 'accepted?');
    a.ghostOnMsg(3, {t:'gc', rid:'t3', i:0, n:1, d:'{}'}); r.push(A.gq && A.gq.n === 0 ? 'wrong sender ignored' : 'accepted?');
    A.gq = null; return {r, cached:A.shared.size}; });
  ok('invalid, oversized, over-chunked and wrong-sender replays are rejected without breaking anything', /invalid/.test(bad.r[0]) && bad.r.slice(1).every(x => /ignored/.test(x)) && bad.cached === 1, JSON.stringify(bad));
  fs.writeFileSync(D + 'ghostshare19.log', out.join('\n') + '\n' + (errs.length ? errs.join('\n') : 'no page errors'));
  console.log(errs.length ? errs.slice(0, 6).join('\n') : 'no page errors'); await b.close();
})();
