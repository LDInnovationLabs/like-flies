// v0.0.19 single-browser checks (desktop Chromium, software WebGL, no network): isolated Tag contact logic, crumb
// placement/codes, Ghost Wings record + replay from a real flown lap, Field Guide scans with real camera/range/visibility.
const { chromium } = require('playwright'); const fs = require('fs');
const { helpers } = require('./racelib16.js');
(async () => {
  const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const ctx = await b.newContext({viewport:{width:900, height:600}}); const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  const D = __dirname + '/s19/', T0 = Date.now(), out = [], ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : '') + '  [' + Math.round((Date.now() - T0) / 1000) + 's]'; out.push(l); console.log(l); };
  await p.goto('http://127.0.0.1:8080/index.html', {timeout:90000}); await p.waitForTimeout(7000); await p.click('#flatBtn'); await p.waitForTimeout(1500);
  await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; });
  const H = helpers(p);
  const until = async (fn, arg, ms) => { for (let t = 0; t < ms; t += 300){ if (await p.evaluate(fn, arg)) return true; await p.waitForTimeout(300); } return false; };
  // ---------- Tag contact logic (synthetic pose samples fed to the real functions)
  const tl = await p.evaluate(() => { const a = window.__likeflies.act, V = THREE.Vector3, A = a.ACT, now = window.__likeflies.now();
    A.poses.delete('xa'); A.poses.delete('xb');
    a.pushPose('xa', now - 0.2, new V(50, 10, 50)); a.pushPose('xa', now, new V(50, 10, 50));
    a.pushPose('xb', now - 0.2, new V(47.5, 10, 50)); a.pushPose('xb', now, new V(52.5, 10, 50));            // 5 m crossing in 0.2 s, straight through
    const cross = a.swept('xa', 'xb', now, 0.25).d;
    A.poses.delete('xc'); a.pushPose('xc', now - 0.2, new V(47.5, 10, 50)); a.pushPose('xc', now, new V(47.5, 10, 52.5));
    const miss = a.swept('xa', 'xc', now, 0.25).d;
    A.poses.delete('xd'); a.pushPose('xd', now - 0.3, new V(10, 10, 10)); a.pushPose('xd', now - 0.25, new V(50, 10, 50.1)); const jumpLen = A.poses.get('xd').length;   // a 40 m jump in 0.05 s: history cleared
    A.poses.delete('xe'); a.pushPose('xe', now - 1.4, new V(50, 10, 50)); a.pushPose('xe', now - 0.9, new V(50, 10, 50)); const stale = a.swept('xa', 'xe', now, 0.25);
    // a wall: find two points 1 m apart with something solid between them, along the house
    let wall = null; const S = window.__likeflies.solids.filter(s => /house/.test(s.label || '') && s.box);
    for (const s of S){ const c = s.box.getCenter(new V()); for (const dx of [-1, 1]) for (const dz of [-1, 1]){ const pa = c.clone(), pb = c.clone(); pa.x += dx * ((s.box.max.x - s.box.min.x) / 2 + 0.4); pa.y = 3; pb.copy(pa); pb.x -= dx * 1.6; if (window.__likeflies.act && !wall){ const occ = window.__likeflies.occluded(pa, pb); if (occ) wall = {pa:pa.toArray(), pb:pb.toArray()}; } } }
    return {cross, miss, jumpLen, stale:!!stale.stale, wall}; });
  ok('a fast straight crossing between two samples is caught (no tunneling)', tl.cross < 0.05, 'closest ' + tl.cross);
  ok('passing 2.5 m to the side is not a tag', tl.miss > 2, 'closest ' + tl.miss.toFixed(2));
  ok('a teleport-sized jump clears contact history', tl.jumpLen === 1);
  ok('a pose older than 0.5 s is stale and never tags', tl.stale);
  ok('the same line-of-sight test the game uses blocks a tag through a house wall', !!tl.wall, JSON.stringify(tl.wall));
  // ---------- crumb placement and codes
  const cr = await p.evaluate(() => { const a = window.__likeflies.act, Y = window.__likeflies.YARD;
    const good = (() => { for (let r = 0; r < 60; r++){ const x = 10 + (r % 10) * 3, z = 20 + Math.floor(r / 10) * 3; if (!a.check([x, 0, z], [0, 1, 0])) return [x, 0, z]; } return null; })();
    return {good, inside:a.check([good[0], -1, good[2]], [0, 1, 0]), air:a.check([good[0], 6, good[2]], [0, 1, 0]), outside:a.check([Y.x1 + 20, 0, 0], [0, 1, 0]), nan:a.check([NaN, 0, 0], [0, 1, 0]), spawn:a.check([window.__likeflies.SPAWNS[0].x, 0, window.__likeflies.SPAWNS[0].z], [0, 1, 0])}; });
  ok('crumb placement: lawn spot accepted; below ground, mid-air, outside the fence, NaN and spawn-can spots rejected', cr.good && cr.inside && cr.air && cr.outside && cr.nan && cr.spawn, JSON.stringify(cr));
  const codes = await p.evaluate(g => { const a = window.__likeflies.act, me = window.__likeflies.race.pid();
    const mk = o => 'LFC1:' + btoa(JSON.stringify(o)); const base = {v:1, id:'friend-abc123', by:'pfriend', n:'Robin', wk:a.world, p:g, nrm:[0, 1, 0], h:2, at:1};
    const r = {};
    r.good = a.importCode(mk(base)); r.again = a.importCode(mk(base)); r.count = a.store.imported.length;
    r.world = a.importCode(mk(Object.assign({}, base, {id:'friend-x2', wk:'otheryard-9'})));
    r.badspot = a.importCode(mk(Object.assign({}, base, {id:'friend-x3', p:[g[0], 9, g[2]]})));
    r.huge = a.importCode('LFC1:' + 'A'.repeat(5000)); r.garbage = a.importCode('LFC1:@@@<script>'); r.notours = a.importCode('{"x":1}');
    r.script = a.importCode(mk(Object.assign({}, base, {id:'friend-x4', n:'<img src=x onerror=alert(1)>'}))); r.nameAfter = (a.store.imported.find(c => c.id === 'friend-x4') || {}).n;
    r.nanv = a.importCode('LFC1:' + btoa('{"v":1,"id":"friend-x5","wk":"' + a.world + '","p":[1e999,0,0],"nrm":[0,1,0],"h":1}'));
    return r; }, cr.good);
  ok('import: a valid friend code works once (no duplicate)', /Imported/.test(codes.good) && codes.count === 1, JSON.stringify({good:codes.good, again:codes.again, count:codes.count}));
  ok('import rejects other yards, bad spots, oversized, garbage, foreign JSON and non-finite data; names are stripped of markup', /different yard/.test(codes.world) && /does not work/.test(codes.badspot) && /too long/.test(codes.huge) && /Not a Like Flies/.test(codes.garbage) && /Not a Like Flies/.test(codes.notours) && /bad data|damaged/.test(codes.nanv) && !/[<>]/.test(codes.nameAfter || ''), JSON.stringify(codes));
  // export roundtrip: hide one locally (offline), export, clear, import in a fresh profile below
  await H.at([cr.good[0], 0.12, cr.good[2]], 2);
  await p.evaluate(async () => { const L = window.__likeflies; L.game.stickCool = 0; L.game.crawl = null; for (let k = 0; k < 60 && !L.game.crawl; k++) await new Promise(r => requestAnimationFrame(r)); });
  await p.evaluate(() => { window.__likeflies.act.crumbStart(); }); await H.frames(4);
  await p.evaluate(() => { const L = window.__likeflies, h = new THREE.Vector3(); L.camera.getWorldPosition(h); });
  await p.screenshot({path:D + 'crumb_0_preview.png'});
  await p.evaluate(() => window.__likeflies.act.crumbConfirm());
  const code = await p.evaluate(() => window.__likeflies.act.exportCode());
  ok('offline hide + export produces a compact code', /^LFC1:/.test(code) && code.length < 600, code.length + ' chars');
  // ---------- Ghost Wings: fly a real lap (solo), then replay it from the same start
  await p.evaluate(() => { const L = window.__likeflies; L.act.store.ghostMode = 'mine'; });
  await H.armAt(4); await H.lap({d:3, step:2, n:1});
  const g1 = await until(() => Object.keys(window.__likeflies.act.ghosts).length > 0, null, 8000);
  const gi = await p.evaluate(() => { const G = Object.values(window.__likeflies.act.ghosts)[0]; return G && {k:G.k, cs:G.cs, n:G.s.length, bytes:JSON.stringify(G).length, valid:window.__likeflies.act.ghostValid(G)}; });
  ok('a really completed lap saves a ghost (about 5 samples a second, small)', g1 && gi.valid && gi.bytes < 131072, JSON.stringify(gi));
  // timed-out run does not replace it
  await p.evaluate(() => { const R = window.__likeflies.race; R.clock.off += 7.5; R.tick(); });
  await H.armAt(4); await H.through(4, 1, {d:3, step:2, n:1}); await H.through(5, 1, {d:3, step:2, n:1});
  await p.evaluate(() => { const R = window.__likeflies.race, st = R.state(); R.clock.off += (st.lastProg + 60.1) - R.now(); R.tick(); });
  const gAfter = await p.evaluate(() => Object.values(window.__likeflies.act.ghosts).map(G => G.cs));
  ok('a timed-out lap does not replace the ghost', gAfter.length === 1 && gAfter[0] === gi.cs, JSON.stringify(gAfter));
  // replay from the same start: the ghost launches at the first gate and follows recorded time
  await H.armAt(4); await H.through(4, 1, {d:3, step:2, n:1});
  const gl = await p.evaluate(() => { const A = window.__likeflies.act.ACT; return {on:!!A.ghost, label:A.ghost && A.ghost.label, why:A.ghostWhy}; });
  await H.through(5, 1, {d:3, step:2, n:1}); await H.frames(3);
  const gpos = await p.evaluate(() => { const A = window.__likeflies.act.ACT, L = window.__likeflies; const R = L.race.state(); return {t:+(L.race.now() - R.t0).toFixed(2), gap:A.gap, i:A.ghost && A.ghost.i}; });
  // look at the ghost for a screenshot
  await p.evaluate(() => { const L = window.__likeflies, A = L.act.ACT; const s = A.ghost.R.s; const h = new THREE.Vector3(); L.camera.getWorldPosition(h); });
  const gv = await p.evaluate(() => { const L = window.__likeflies; let gp = null; L.scene.traverse(o => { if (!gp && o.isGroup && o.userData.w && o.visible) gp = o.position.clone(); }); return gp && gp.toArray(); });
  if (gv){ const R = 2.2; await p.evaluate(gv => { const L = window.__likeflies, V = THREE.Vector3; const pos = new V(gv[0] + 1.6, gv[1] + 0.7, gv[2] + 1.6); L.game.crawl = null; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); const h = new V(); L.camera.getWorldPosition(h); L.rig.position.add(pos.clone().sub(h)); const d = new V(gv[0], gv[1], gv[2]).sub(pos); L.setLook(Math.atan2(-d.x, -d.z), Math.atan2(d.y, Math.hypot(d.x, d.z))); }, gv); await H.frames(3); await p.screenshot({path:D + 'ghost_1_visible_in_race.png'}); }
  ok('same start: the ghost plays from the first accepted gate on recorded time, with a same-gate time gap', gl.on && gl.label === 'My best' && gv && gpos.gap != null, JSON.stringify({gl, gpos, gv}));
  await p.evaluate(() => { const R = window.__likeflies.race; R.clock.off += 70; R.tick(); });
  await H.armAt(7); await H.through(7, 1, {d:3, step:2, n:1});
  const gm = await p.evaluate(() => { const A = window.__likeflies.act.ACT; return {on:!!A.ghost, why:A.ghostWhy}; });
  ok('a different start ring: "No matching ghost for this start", nothing shown', !gm.on && /No matching ghost/.test(gm.why), JSON.stringify(gm));
  const bad = await p.evaluate(() => { const v = window.__likeflies.act.ghostValid; return [v({s:[[0, 0, 0, 0, 0]], start:0, sig:'x', cs:500}), v({s:[[10, 0, 0, 0, 0], [5, 0, 0, 0, 0]], start:0, sig:'x', cs:500}), v({s:[[0, 1e9, 0, 0, 0], [5, 0, 0, 0, 0]], start:0, sig:'x', cs:500}), v({s:new Array(4000).fill([0, 0, 0, 0, 0]), start:0, sig:'x', cs:500})]; });
  ok('invalid replays are rejected (too short, time going backwards, far outside the yard, too many samples)', bad.every(x => !x), JSON.stringify(bad));
  await p.evaluate(() => { const R = window.__likeflies.race; R.clock.off += 70; R.tick(); });
  // ---------- Field Guide: real camera, range and visibility
  await p.evaluate(() => { window.__likeflies.act.store.scan = true; });
  const targets = await p.evaluate(() => { const A = window.__likeflies.act.ACT; return Object.fromEntries(Object.entries(A.guideT).map(([k, t]) => [k, {c:t.bc.toArray().map(v => +v.toFixed(2)), r:+(t.br || 0).toFixed(2), label:t.label}])); });
  // look-away and through-wall first (the chicken: find a spot where its body is hidden)
  const aim = (pos, tgt) => p.evaluate(([pos, tgt]) => { const L = window.__likeflies, V = THREE.Vector3; L.game.crawl = null; L.game.level = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); const h = new V(); L.camera.getWorldPosition(h); L.rig.position.add(new V(...pos).sub(h)); const d = new V(...tgt).sub(new V(...pos)); L.setLook(Math.atan2(-d.x, -d.z), Math.atan2(d.y, Math.hypot(d.x, d.z))); }, [pos, tgt]);
  const spot = (id, wantBlocked) => p.evaluate(([id, wantBlocked]) => { const L = window.__likeflies, V = THREE.Vector3, t = L.act.ACT.guideT[id], r = Math.max(0.3, (t.br || 1) * 0.7);
    for (const dist of [r + 2.5, r + 4, r + 6]) for (let k = 0; k < 16; k++) for (const up of [0.3, 1.2, -0.2]){ const a = k / 16 * Math.PI * 2, pos = new V(t.bc.x + Math.cos(a) * dist, t.bc.y + up * r + 0.3, t.bc.z + Math.sin(a) * dist);
      if (pos.y < 0.3) continue; if (L.fieldAt(pos.toArray()).d < 0.3) continue; const v = t.bc.clone().sub(pos), d = v.length(), near = t.bc.clone().addScaledVector(v, -Math.min(r * 1.02, d * 0.5) / d);
      if (L.occluded(pos, near) === wantBlocked) return pos.toArray(); } return null; }, [id, wantBlocked]);
  const prog = () => p.evaluate(() => ({p:window.__likeflies.act.ACT.scanP, t:window.__likeflies.act.ACT.scanTgt, n:Object.keys(window.__likeflies.act.store.guide).length}));
  const sp0 = await spot('chicken', false); await aim(sp0, [sp0[0] + 5, sp0[1], sp0[2] + 5]); await p.waitForTimeout(3500);
  const away = await prog(); ok('looking away from a nearby target makes no progress', away.n === 0 && !away.t, JSON.stringify(away));
  const blk = await spot('chicken', true);
  if (blk){ await aim(blk, targets.chicken.c); await p.waitForTimeout(4500); } const thru = await prog();
  ok('looking at the chicken through something solid does not scan it', !!blk && thru.n === 0, JSON.stringify({blk, thru}));
  const duck0 = targets.duck.c; await p.waitForTimeout(1500); const duck1 = await p.evaluate(() => window.__likeflies.act.ACT.guideT.duck.bc.toArray().map(v => +v.toFixed(2)));
  ok('the duck target follows the live duck', JSON.stringify(duck0) !== JSON.stringify(duck1), JSON.stringify({duck0, duck1}));
  const got = {};
  for (const id of ['sunflower', 'chicken', 'duck', 'tomato', 'moth']){
    const sp = await spot(id, false); if (!sp){ got[id] = 'no clear viewpoint'; continue; }
    for (let k = 0; k < 40; k++){ const c = await p.evaluate(id => window.__likeflies.act.ACT.guideT[id].bc.toArray(), id); await aim(sp, c); await p.waitForTimeout(300); if (await p.evaluate(id => !!window.__likeflies.act.store.guide[id], id)) break; if (k === 6 && id === 'duck') await p.screenshot({path:D + 'guide_1_scanning_duck.png'}); }
    got[id] = await p.evaluate(id => !!window.__likeflies.act.store.guide[id], id);
  }
  ok('all five Field Guide targets can be discovered by really looking at them', Object.values(got).every(v => v === true), JSON.stringify({got, targets}));
  const again = await p.evaluate(() => { const s = window.__likeflies.act.store; return Object.keys(s.guide).length; });
  // persistence across reload (same browser)
  await p.evaluate(() => { const L = window.__likeflies; L.act.store.scan = false; }); await p.evaluate(() => document.querySelector('#toMenu') && document.querySelector('#toMenu').click());
  await p.reload({timeout:90000}); await p.waitForTimeout(7000);
  const after = await p.evaluate(() => ({guide:Object.keys(window.__likeflies.act.store.guide).length, ghosts:Object.keys(window.__likeflies.act.ghosts).length, mine:!!window.__likeflies.act.store.mine, imported:window.__likeflies.act.store.imported.length}));
  ok('journal, ghost, my crumb and imports survive a reload on this browser', after.guide === 5 && after.ghosts === 1 && after.mine && after.imported >= 1, JSON.stringify(after));
  await p.evaluate(() => { const b = document.querySelector('#actBox'); b.scrollIntoView(); }); await p.waitForTimeout(600);
  await p.evaluate(() => { const els = [...document.querySelectorAll('.actcard')]; els[3] && els[3].scrollIntoView(); }); await p.waitForTimeout(400); await p.screenshot({path:D + 'guide_2_journal_page.png'});
  fs.writeFileSync(D + 'panel_activities_after.png', Buffer.from((await p.evaluate(() => window.__likeflies.panelImage('Activities'))).split(',')[1], 'base64'));
  fs.writeFileSync(D + 'logic19.log', out.join('\n') + '\n' + (errs.length ? errs.join('\n') : 'no page errors'));
  console.log(errs.length ? errs.slice(0, 6).join('\n') : 'no page errors'); await b.close();
})();
