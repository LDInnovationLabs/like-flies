// v0.0.19b: role switch leaves Tag and racing re-arms (desktop, single browser, real game loop); plus a SYNTHETIC check that a
// valid snapshot from the current coordinator connection (offline: my own slot) with a new epoch is still accepted.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']}); const p = await b.newPage({viewport:{width:400, height:300}}); const errs = []; p.on('pageerror', e => errs.push(e.stack || e.message));
  const out = [], ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : ''); out.push(l); console.log(l); };
  await p.goto('http://127.0.0.1:8080/index.html', {timeout:90000}); await p.waitForTimeout(7000); await p.click('#flatBtn'); await p.waitForTimeout(1500);
  const fr = n => p.evaluate(n => new Promise(res => { let k = 0; const f = () => ++k >= n ? res() : requestAnimationFrame(f); requestAnimationFrame(f); }), n);
  const st = () => p.evaluate(() => { const L = window.__likeflies; return {race:L.race.state().phase, inTag:!!L.act.ACT.snap.tag.mem[L.race.pid()], want:!!L.act.ACT.wantTag, pas:L.act.ACT.snap.tag.pas[L.race.pid()] || 0, role:L.game.role, hud:document.querySelector('#hudText').textContent.slice(0, 90)}; });
  const s0 = await st(); await p.evaluate(() => window.__likeflies.act.join()); await fr(8); const s1 = await st();
  ok('joining Tag pauses automatic race starts and shows the Tag line', s0.race === 'armed' && s1.inTag && s1.race === 'off' && /Buzz Tag/.test(s1.hud), JSON.stringify({s0, s1}));
  await p.evaluate(() => window.__likeflies.setRole('human', 0)); await fr(10); const s2 = await st();
  ok('switching to Human leaves Tag at once, no points', !s2.inTag && !s2.want && s2.pas === 0, JSON.stringify(s2));
  await p.evaluate(() => window.__likeflies.setRole('fly', 0)); await fr(40); const s3 = await st();
  ok('back as a fly (not in Tag): racing re-arms on its own', s3.race === 'armed' && !s3.inTag, JSON.stringify(s3));
  await p.evaluate(() => window.__likeflies.act.join()); await fr(6); await p.evaluate(() => window.__likeflies.act.leave()); await fr(40); const s4 = await st();
  ok('explicit Leave: racing re-arms', s4.race === 'armed' && !s4.inTag, JSON.stringify(s4));
  const legit = await p.evaluate(() => { const L = window.__likeflies, a = L.act, A = a.ACT, host = L.race.host(); const d = JSON.parse(JSON.stringify(Object.assign({t:'as'}, A.snap))); d.ep = A.snap.ep + 1; d.rev = A.snap.rev + 1; d.hs = host; d.tag.pas = {zz:2}; a.onSnap(host, d); return {ep:A.snap.ep, pas:A.snap.tag.pas.zz, host}; });
  ok('SYNTHETIC: a valid newer snapshot from the current coordinator connection is accepted', legit.pas === 2, JSON.stringify(legit));
  fs.writeFileSync(__dirname + '/s19b/role19b.log', out.join('\n') + '\n' + (errs.length ? errs.join('\n') : 'no page errors'));
  console.log(errs.length ? errs.slice(0, 4).join('\n') : 'no page errors'); await b.close(); })();
