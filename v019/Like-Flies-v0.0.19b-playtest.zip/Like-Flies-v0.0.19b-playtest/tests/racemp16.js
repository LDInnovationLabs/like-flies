// v0.0.16 multi-peer race ledger test: real pages, real local PeerJS room, scripted gate traversals through the actual detector (racelib16 repositions the rig via H.at; not human input flight), moving the fly rig through
// real frames. Elapsed times are set with the test-only race clock offset just before the last gate (labelled "simulated time").
const { chromium } = require('playwright');
const { helpers } = require('./racelib16.js');
(async () => {
  const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const room = 'rc' + Date.now() % 100000, url = `http://127.0.0.1:8080/index.html?room=${room}&peerhost=127.0.0.1:9000`;
  const errs = [], out = [];
  const ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : ''); out.push(l); console.log(l); };
  const mk = async (name, u) => { const c = await b.newContext({viewport:{width:260, height:170}}); const p = await c.newPage(); p.on('pageerror', e => errs.push(name + ': ' + e.message));
    await p.goto(u || url, {timeout:120000}); await p.fill('#mpName', name); await p.dispatchEvent('#mpName', 'input'); p.H = helpers(p); p.nm = name; return p; };
  const conns = p => p.evaluate(() => [...window.__likeflies.net.conns.values()].filter(c => c.open).length);
  const waitConns = async (p, n, ms) => { for (let t = 0; t < (ms || 60000); t += 1000){ if (await conns(p) >= n) return true; await p.waitForTimeout(1000); } return false; };
  const until = async (p, fn, arg, ms) => { for (let t = 0; t < (ms || 30000); t += 500){ if (await p.evaluate(fn, arg)) return true; await p.waitForTimeout(500); } return false; };
  // a joiner may arm a run before the room tuning arrives (then that run is correctly Practice); tests wait for it first
  const sameComp = (p, sig) => until(p, s => window.__likeflies.race.compSig() === s && window.__likeflies.race.localSig() === s, sig);
  const play = async p => { await p.click('#flatBtn'); await p.waitForTimeout(800); };
  const L = p => p.H.ledger(), S = p => p.H.state();
  const pts = (led, pid) => led.points[pid] || 0;
  const board = p => p.evaluate(() => window.__likeflies.race.board());
  const pid = p => p.evaluate(() => window.__likeflies.race.pid());
  const fast = {d:3, step:2, n:1};
  // simulated time: before gate k (k = 1..N-1) move the race clock so the run reads about target*k/(N-1) seconds there.
  // Spreading it across the gates keeps every gap far below the 60 s inactivity reset, like a real ~target-second lap.
  const simTo = (p, target, k) => p.evaluate(([t, k]) => { const R = window.__likeflies.race, st = R.state(); const want = st.t0 + t * k / 9 - 0.3 * (k === 9 ? 1 : 0); if (want > R.now()) R.clock.off += want - R.now(); }, [target, k]);
  // fly a full lap from the nearest ring; the race clock is moved so the run reads about `target` seconds at the last gate
  const lap = async (p, target, armRing) => {
    if (armRing != null) await p.H.armAt(armRing);
    await p.H.lap(Object.assign({}, fast, {beforeEach:async k => { if (k) await simTo(p, target, k); }}));
    for (let k = 0; k < 20; k++){ const s = await S(p); if (s.result && s.result.status !== 'pending') return s.result; await p.waitForTimeout(800); }
    return (await S(p)).result;
  };
  const publish = async (p, vals) => { await p.evaluate(v => { for (const [k, x] of Object.entries(v)){ const i = document.querySelector('#t_' + k); i.value = x; i.dispatchEvent(new Event('input')); } document.querySelector('#tShare').click(); }, vals); };

  const A = await mk('Job'); await A.waitForTimeout(7000); await play(A);
  await publish(A, {gravity:0, bots:0}); await A.waitForTimeout(1500);
  const comp1 = await A.evaluate(() => window.__likeflies.race.compSig());
  const [pA] = [await pid(A)];
  // 1. Job's first room finish: crown + 1 point
  const r1 = await lap(A, 200, 0);
  let la = await L(A);
  ok('first room finish (~200 s): Job #1, crown, 1 race point', r1 && r1.status === 'record' && r1.ranked && la.boards[comp1].crown.pid === pA && pts(la, pA) === 1, JSON.stringify({cs:r1 && r1.cs, status:r1 && r1.status}));
  // 2. Robin joins later and immediately has the board
  const B = await mk('Robin'); await waitConns(B, 1); const bJoin = await sameComp(B, comp1); await until(B, () => window.__likeflies.race.ledger().rev > 0); await play(B);
  const pB = await pid(B); let lb = await L(B);
  ok('late joiner receives the room tuning, board, crown and points', bJoin && lb.boards[comp1] && lb.boards[comp1].crown && lb.boards[comp1].crown.pid === pA && pts(lb, pA) === 1 && (await B.evaluate(() => window.__likeflies.race.compSig())) === comp1);
  const r2 = await lap(B, 80, 3);
  la = await L(A);
  ok('Robin ~80 s: takes the crown, +1; Job keeps his point', r2.status === 'record' && la.boards[comp1].crown.pid === pB && pts(la, pB) === 1 && pts(la, pA) === 1, JSON.stringify({cs:r2.cs, status:r2.status}));
  // 3. independence: Job mid-run while Robin dies, Robin turns human, a third fly joins
  await A.H.armAt(5); await A.H.through(5, 1, fast); await A.H.through(6, 1, fast);
  const aMid = await S(A);
  // test-only: while the other clients do slow page loads, hold Job's no-progress gap under 30 s of race clock (software
  // rendering makes real waits long); this pulls the test clock offset back and never touches race state
  await A.evaluate(() => { const R = window.__likeflies.race; window.__hold = setInterval(() => { const s = R.state(); if (s.phase === 'running' && R.now() - s.lastProg > 30) R.clock.off -= (R.now() - s.lastProg) - 5; }, 500); });
  await B.evaluate(() => { const L = window.__likeflies; for (let k = 0; k < 4; k++){ L.game.immuneUntil = 0; L.hit([0, 0, 30]); } });
  await B.waitForTimeout(2000);
  await B.evaluate(() => window.__likeflies.setRole('human', 0)); await B.waitForTimeout(1500);
  const C = await mk('Sage'); await waitConns(C, 2); await C.waitForTimeout(2000); await play(C); const cJoin = await sameComp(C, comp1);
  const aAfter = await S(A), bS = await S(B); await A.evaluate(() => clearInterval(window.__hold));
  ok('Job\'s run is untouched by Robin dying, turning human and Sage joining', aAfter.phase === 'running' && aAfter.runId === aMid.runId && aAfter.done === aMid.done && aAfter.t0 === aMid.t0, JSON.stringify({before:[aMid.phase, aMid.done], after:[aAfter.phase, aAfter.done], robin:bS.phase}));
  await B.evaluate(() => window.__likeflies.setRole('fly', 0)); await B.waitForTimeout(1500); await play(B).catch(() => {}); await sameComp(B, comp1);
  // finish Job's run at ~85 s: personal best improves, Robin keeps the crown, no point
  { const st = await S(A); const N = 10; for (let k = st.done; k < N; k++){ const i = (st.start + k) % N; if (k) await simTo(A, 150, k); await A.H.through(i, 1, fast); } }
  let r3; for (let k = 0; k < 20; k++){ r3 = (await S(A)).result; if (r3 && r3.status !== 'pending') break; await A.waitForTimeout(800); }
  la = await L(A); let bd = await board(A);
  ok('Job ~150 s: his row improves from 200, Robin keeps the crown, no new point', r3.status === 'pb' && la.boards[comp1].rows[pA].cs === r3.cs && la.boards[comp1].crown.pid === pB && pts(la, pA) === 1, JSON.stringify({cs:r3.cs, status:r3.status, rows:bd.rows.map(r => r.name + ' ' + r.cs + ' ' + r.pts)}));
  // 4. Robin improves her own record: +1
  const r4 = await lap(B, 75, 1);
  la = await L(A);
  ok('Robin ~75 s: new room record, +1 (2 total), crown stays', r4.status === 'record' && pts(la, pB) === 2 && la.boards[comp1].crown.cs === r4.cs, JSON.stringify({cs:r4.cs, status:r4.status}));
  // a slower run by Robin does not replace her best row
  const r5 = await lap(B, 95, 2); la = await L(A);
  ok('a slower later run does not replace the best row or earn a point', r5.status === 'slower' && la.boards[comp1].rows[pB].cs === r4.cs && pts(la, pB) === 2, r5.status);
  // 5. exact tie at the canonical time (synthetic but well-formed submission sent over the real room link)
  const tieSub = await C.evaluate(([cs, sig]) => { const L = window.__likeflies, N = 10, st = 4, tr = [], tcs = []; for (let k = 0; k < N; k++){ tr.push((st + k) % N); tcs.push(Math.round(cs * k / (N - 1))); }
    return {t:'rs', runId:L.race.pid() + '.tie', pid:L.race.pid(), name:'Sage', sig, start:st, cs, trace:tr, tcs}; }, [r4.cs, comp1]);
  const send = (p, sub) => p.evaluate(sub => { const L = window.__likeflies, h = L.tuneHost(), c = L.net.conns.get(h); c.send(sub); }, sub);
  await send(C, tieSub); await C.waitForTimeout(2500); la = await L(A);
  ok('a tie at the canonical recorded time: no point, incumbent keeps the crown', la.accepted[tieSub.runId] && la.accepted[tieSub.runId].status === 'tie' && la.boards[comp1].crown.pid === pB && pts(la, tieSub.pid) === 0, JSON.stringify(la.accepted[tieSub.runId]));
  // 6. duplicates, retries, renamed display name, reordered/stale ledger packets
  const rev0 = la.rev; const robinRun = r4.runId;
  const dupe = await B.evaluate(() => window.__likeflies.race.state().events.length);
  await B.evaluate(rid => { const L = window.__likeflies; const h = L.tuneHost(), c = L.net.conns.get(h); const s = L.race.ledger(); c.send({t:'rs', runId:rid, pid:L.race.pid(), name:'Robin Renamed', sig:L.race.compSig(), start:1, cs:7500, trace:[1,2,3,4,5,6,7,8,9,0], tcs:[0,800,1600,2400,3200,4000,4800,5600,6400,7500]}); }, robinRun);
  await send(C, tieSub); await B.waitForTimeout(2500); la = await L(A);
  ok('duplicate run ids (retry, replay, renamed sender) earn nothing new', pts(la, pB) === 2 && pts(la, tieSub.pid) === 0 && la.names[pB] === 'Robin', JSON.stringify({robinPts:pts(la, pB), name:la.names[pB]}));
  const stale = await A.evaluate(() => { const L = window.__likeflies, s = L.race.ledger(); return Object.assign({t:'rl'}, s, {rev:1, points:{x:99}}); });
  await A.evaluate(m => { const L = window.__likeflies; for (const c of L.net.conns.values()) c.send(m); }, stale); await B.waitForTimeout(1500);
  lb = await L(B); ok('an old (reordered) ledger packet is ignored', !lb.points.x && lb.rev >= rev0, 'rev ' + lb.rev);
  // 7. malformed or implausible finishes are rejected
  const bad = await C.evaluate(sig => { const L = window.__likeflies, me = L.race.pid(), ok = (st) => { const tr = [], tcs = []; for (let k = 0; k < 10; k++){ tr.push((st + k) % 10); tcs.push(k * 900); } return {tr, tcs}; };
    const g = ok(0); return [
      {t:'rs', runId:me + '.b1', pid:me, name:'Sage', sig:'Cdeadbeef', start:0, cs:8100, trace:g.tr, tcs:g.tcs},
      {t:'rs', runId:me + '.b2', pid:me, name:'Sage', sig, start:0, cs:8100, trace:[0,1,2,3,4,5,6,7,9,8], tcs:g.tcs},
      {t:'rs', runId:me + '.b3', pid:me, name:'Sage', sig, start:0, cs:8100, trace:g.tr.slice(0, 9), tcs:g.tcs.slice(0, 9)},
      {t:'rs', runId:me + '.b4', pid:me, name:'Sage', sig, start:0, cs:20, trace:g.tr, tcs:[0,2,4,6,8,10,12,14,16,20]},
      {t:'rs', runId:me + '.b5', pid:me, name:'Sage', sig, start:0, cs:NaN, trace:g.tr, tcs:g.tcs}]; }, comp1);
  for (const sb of bad) await send(C, sb); await C.waitForTimeout(3000); la = await L(A);
  ok('wrong competition, out-of-order, incomplete, implausible and non-finite finishes rejected', bad.every(sb => la.accepted[sb.runId] ? la.accepted[sb.runId].status === 'rejected' : sb.cs !== sb.cs) && la.boards[comp1].crown.pid === pB, bad.map(sb => la.accepted[sb.runId] ? la.accepted[sb.runId].why : 'dropped').join(' | '));
  // 8. the record holder leaves: her record stays
  await B.context().close(); await A.waitForTimeout(4000); la = await L(A);
  ok('the departed record holder keeps her crown and points on the board', la.boards[comp1].crown.pid === pB && pts(la, pB) === 2 && (await board(A)).rows.some(r => r.pid === pB && r.crown));
  // 9. host migration: Job (host) leaves; Sage hosts; a new record is accepted with rising revision; a late joiner gets it
  const revBefore = (await L(C)).rev;
  await A.context().close(); await C.waitForTimeout(5000);
  ok('Sage is now the race host', await until(C, () => window.__likeflies.tuneHost() === window.__likeflies.net.slot, null, 40000));
  const pC = await pid(C); const r6 = await lap(C, 70, 7);
  let lc = await L(C);
  ok('after host migration a faster run is accepted: crown Sage, +1, revision continues', r6.status === 'record' && lc.boards[comp1].crown.pid === pC && pts(lc, pC) === 1 && pts(lc, pB) === 2 && pts(lc, pA) === 1 && lc.rev > revBefore, JSON.stringify({cs:r6.cs, rev:[revBefore, lc.rev]}));
  const D = await mk('Late'); await waitConns(D, 1); await sameComp(D, comp1); await until(D, () => window.__likeflies.race.ledger().rev > 0); await play(D);
  let ld = await L(D);
  ok('late joiner after migration gets the board and points', ld.boards[comp1] && ld.boards[comp1].crown.pid === pC && pts(ld, pA) === 1 && pts(ld, pB) === 2 && pts(ld, pC) === 1);
  // 10. a different room never bleeds in
  const E = await mk('Other', url.replace(room, room + 'x')); await E.waitForTimeout(7000); await play(E);
  await publish(E, {gravity:0, bots:0}); await E.waitForTimeout(1500); const rE = await lap(E, 30, 0);
  const le = await L(E); ok('room 2 has its own record', rE.status === 'record' && le.rev > 0);
  await E.evaluate(() => document.querySelector('#mpJoin').click()); await E.waitForTimeout(1500);
  const eLeft = await L(E); ok('leaving room 2 clears its board locally', eLeft.rev === 0 && !Object.keys(eLeft.boards).length);
  await E.evaluate(rm => { document.querySelector('#mpRoom').value = rm; document.querySelector('#mpJoin').click(); }, room);
  await waitConns(E, 2); await sameComp(E, comp1); await until(E, () => window.__likeflies.race.ledger().room !== '' && Object.keys(window.__likeflies.race.ledger().boards).length > 0);
  const le2 = await L(E), lc2 = await L(C);
  ok('moving into room 1: room 2\'s record is gone, room 1\'s board is unchanged', le2.boards[comp1] && le2.boards[comp1].crown.pid === pC && !Object.values(le2.accepted).some(a => a.cs === rE.cs) && lc2.boards[comp1].crown.pid === pC && !lc2.accepted[rE.runId], JSON.stringify({rev:le2.rev}));
  // 11. tuning: local mismatch = Practice; mid-run change = Practice; a new room tuning = a fresh competition, points kept
  const brake0 = await D.evaluate(() => document.querySelector('#t_brake').value);
  await D.evaluate(() => { const i = document.querySelector('#t_brake'); i.value = +i.value === 2 ? 1.5 : 2; i.dispatchEvent(new Event('input')); });
  const rp = await lap(D, 50, 0);
  ok('local slider mismatch: Practice with a reason, not submitted', rp.status === 'practice' && /differ/.test(rp.practice) && !(await L(C)).accepted[rp.runId], rp.practice);
  await D.evaluate(v => { const i = document.querySelector('#t_brake'); i.value = v; i.dispatchEvent(new Event('input')); }, brake0);
  ok('restoring the slider returns to the ranked competition', (await D.evaluate(() => window.__likeflies.race.localSig() === window.__likeflies.race.compSig())));
  await D.H.armAt(2); await D.H.through(2, 1, fast); await D.H.through(3, 1, fast);
  await D.evaluate(() => { const i = document.querySelector('#t_turn'); i.value = 4; i.dispatchEvent(new Event('input')); });
  { const st = await S(D); for (let k = st.done; k < 10; k++) await D.H.through((st.start + k) % 10, 1, fast); }
  let rm; for (let k = 0; k < 10; k++){ rm = (await S(D)).result; if (rm) break; await D.waitForTimeout(500); }
  ok('tuning changed mid-run: Practice', rm && rm.status === 'practice' && /during the run/.test(rm.practice), rm && rm.practice);
  await publish(D, {turn:4}); await D.waitForTimeout(2500);
  const comp2 = await C.evaluate(() => window.__likeflies.race.compSig());
  bd = await board(C);
  ok('new room tuning = a fresh competition board; race points kept', comp2 !== comp1 && !bd.crown && bd.rows.every(r => r.cs == null) && bd.rows.find(r => r.pid === pB).pts === 2, comp1 + ' -> ' + comp2);
  const r7 = await lap(D, 99, 5); lc = await L(C);
  ok('first finish in the new competition: crown and +1 (no mixed-physics comparison with 70 s)', r7.status === 'record' && lc.boards[comp2].crown.pid === (await pid(D)) && lc.boards[comp1].crown.pid === pC, JSON.stringify({cs:r7.cs}));
  // screenshots of the live board and HUD
  await C.setViewportSize({width:900, height:700}); await C.keyboard.press('Escape'); await C.waitForTimeout(1500);
  await C.evaluate(() => { document.querySelector('#raceBox').scrollIntoView(); }); await C.waitForTimeout(800);
  await C.screenshot({path:__dirname + '/s16/board_page.png'});
  require('fs').writeFileSync(__dirname + '/s16/vr_race_tab_board.png', Buffer.from((await C.evaluate(() => window.__likeflies.panelImage('Race'))).split(',')[1], 'base64'));
  await D.setViewportSize({width:1100, height:700}); await D.waitForTimeout(1500); await D.screenshot({path:__dirname + '/s16/board_hud_crown.png'});
  console.log('board', JSON.stringify(await board(C)));
  console.log(errs.length ? errs.slice(0, 6).join('\n') : 'no page errors');
  await b.close();
})();
