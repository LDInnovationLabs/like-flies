// v0.0.19b focused regression (single desktop browser, exact built source, no network). Everything here is SYNTHETIC:
// codes, snapshots and pose samples are fed straight into the game's own functions.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const p = await (await b.newContext({viewport:{width:640, height:420}})).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.stack || e.message));
  const D = __dirname + '/s19b/'; fs.mkdirSync(D, {recursive:true});
  const out = [], ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : ''); out.push(l); console.log(l); };
  await p.goto('http://127.0.0.1:8080/index.html', {timeout:90000}); await p.waitForTimeout(7000); await p.click('#flatBtn'); await p.waitForTimeout(1200);
  await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; });
  // ---------- 1. imported friend crumb: the importer can search and find it; the original hider cannot; only the manager can delete
  const spot = await p.evaluate(() => { const a = window.__likeflies.act; for (let r = 0; r < 60; r++){ const x = 10 + (r % 10) * 3, z = 20 + Math.floor(r / 10) * 3; if (!a.check([x, 0, z], [0, 1, 0])) return [x, 0, z]; } return null; });
  const imp = await p.evaluate(sp => { const a = window.__likeflies.act; const code = 'LFC1:' + btoa(JSON.stringify({v:1, id:'pfriend9-abc123', by:'pfriend9', n:'Robin', wk:a.world, p:sp, nrm:[0, 1, 0], h:2, at:1}));
    const msg = a.importCode(code); const L = a.ACT; const list = window.__likeflies.act.cards; const idx = (() => { const ids = []; for (const c of Object.values(L.snap.crumbs)) ids.push(c.id); return 0; })();
    // pick it in the browse list and start searching
    let k = 0; for (; k < 10; k++){ L.sel = k; const st = a.cards(0)[1].status; if (/Robin/.test(st)) break; }
    a.search(); return {msg, searching:L.search, card:a.cards(0)[1].status}; }, spot);
  ok('import, then Find this: the importer is allowed to search a friend crumb (offline)', imp.searching === 'pfriend9-abc123', JSON.stringify(imp));
  await p.evaluate(sp => { const L = window.__likeflies, V = THREE.Vector3, h = new V(); L.game.crawl = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); L.camera.getWorldPosition(h); L.rig.position.add(new V(sp[0] + 0.2 - h.x, 0.35 - h.y, sp[2] - h.z)); L.setLook(0, -1.2); }, spot);
  let found = false; for (let k = 0; k < 25 && !found; k++){ await p.waitForTimeout(300); found = await p.evaluate(() => window.__likeflies.act.store.found.includes('pfriend9-abc123')); }
  ok('the importer finds the imported friend crumb (offline, real proximity + view + dwell)', found);
  const room = await p.evaluate(sp => { const L = window.__likeflies, a = L.act, A = a.ACT, me = L.race.pid(), V = THREE.Vector3, now = L.now();
    A.snap.crumbs['pfriend9-xyz789'] = {v:1, id:'pfriend9-xyz789', by:'pfriend9', n:'Robin', wk:a.world, p:sp, nrm:[0, 1, 0], h:1, at:1, own:me, imp:1}; A.snap.finds['pfriend9-xyz789'] = [];
    a.pushPose('pfriend9', now - 0.05, new V(sp[0], 0.3, sp[2])); a.pushPose('pfriend9', now, new V(sp[0], 0.3, sp[2]));
    a.apply('pfriend9', {op:'find', cid:'pfriend9-xyz789', id:'t-hider-find'});                    // the original hider: denied
    const afterHider = A.snap.finds['pfriend9-xyz789'].slice();
    a.apply(me, {op:'find', cid:'pfriend9-xyz789', id:'t-importer-find'});                         // the importer (my pose is right there): allowed
    const afterMe = A.snap.finds['pfriend9-xyz789'].slice();
    a.apply('pfriend9', {op:'unhide', cid:'pfriend9-xyz789', id:'t-hider-del'}); const stillThere = !!A.snap.crumbs['pfriend9-xyz789'];
    a.apply('pfriend9', {op:'import', ch:Object.assign({}, A.snap.crumbs['pfriend9-xyz789'], {p:[sp[0] + 3, 0, sp[2]]}), id:'t-hider-move'}); const notMoved = A.snap.crumbs['pfriend9-xyz789'].p[0] === sp[0];
    return {afterHider, afterMe:afterMe.length, stillThere, notMoved, me:me.slice(-5)}; }, spot);
  ok('in a room: the original hider is denied a find; the importer is credited; the original hider cannot delete or move the imported copy', room.afterHider.length === 0 && room.afterMe === 1 && room.stillThere && room.notMoved, JSON.stringify(room));
  // ---------- 2. snapshot authority and structure
  const snap = await p.evaluate(() => { const L = window.__likeflies, a = L.act, A = a.ACT, S0 = JSON.stringify(A.snap), host = L.race.host(), r = {};
    const good = () => JSON.parse(JSON.stringify(Object.assign({t:'as'}, A.snap)));
    const tryIt = (j, d) => { try{ a.onSnap(j, d); return 'ok'; }catch(e){ return 'THREW ' + e.message; } };
    let d = good(); d.ep = 99; d.hs = 7; d.tag.mem = {}; r.spoof = tryIt(7, d); r.spoofApplied = A.snap.ep === 99; r.held = !!A.pendSnap;
    d = good(); d.ep = 99; d.hs = host; r.mismatch = tryIt(7, d); r.mismatchApplied = A.snap.ep === 99;
    const bad = [x => { x.tag.mem = null; }, x => { x.tag.pas = {a:-3}; }, x => { x.tag.sep = 'zz'; }, x => { x.finds = {q:[1, 2]}; }, x => { x.tag.it = 'nobody'; }, x => { x.names = {a:{}}; }, x => { x.crumbs = {z:{id:'z'}}; }, x => { x.tag = null; }];
    r.malformed = bad.map(f => { const x = good(); x.ep = 50; x.hs = host; f(x); return tryIt(host, x) + (A.snap.ep === 50 ? ' APPLIED' : ''); });
    r.unchanged = JSON.stringify(A.snap) === S0;
    return r; });
  ok('a spoofed high-epoch snapshot from a non-coordinator is held, never applied', snap.spoof === 'ok' && !snap.spoofApplied && snap.held, JSON.stringify(snap));
  ok('a snapshot whose stated coordinator is not the sending connection is rejected', snap.mismatch === 'ok' && !snap.mismatchApplied);
  ok('8 malformed snapshots (null members, negative passes, bad lists, unknown IT, bad names/crumbs, no tag) rejected without throwing; state unchanged', snap.malformed.every(x => x === 'ok') && snap.unchanged, JSON.stringify(snap.malformed));
  await p.evaluate(() => { const P = window.__likeflies.act.ACT.pendSnap; if (P) P.t -= 9; });   // SYNTHETIC: age the hold by 9 s instead of waiting (the game clock runs slow in software rendering)
  let exp = false; for (let k = 0; k < 20 && !exp; k++){ await p.waitForTimeout(300); exp = await p.evaluate(() => !window.__likeflies.act.ACT.pendSnap); }
  ok('the held spoof expires on its own (8 s of game time) and is never applied', exp && await p.evaluate(() => window.__likeflies.act.ACT.snap.ep !== 99));
  // ---------- 3. Buzz Tag fly-by timing: old sweep vs new, on delayed / uneven / bunched samples
  const sim = await p.evaluate(() => {
    const a = window.__likeflies.act, A = a.ACT, V = THREE.Vector3, reach = 0.275, res = {};
    // old v19 rule, re-implemented here only for comparison: window now-0.25, samples stamped at arrival, newest held
    function oldSwept(PA, PB, now){ const at = (B, t) => { if (t <= B[0].t) return new V(B[0].x, B[0].y, B[0].z); for (let i = 1; i < B.length; i++) if (B[i].t >= t){ const u = (t - B[i - 1].t) / Math.max(1e-6, B[i].t - B[i - 1].t); return new V(B[i - 1].x + (B[i].x - B[i - 1].x) * u, B[i - 1].y + (B[i].y - B[i - 1].y) * u, B[i - 1].z + (B[i].z - B[i - 1].z) * u); } const L = B[B.length - 1]; return new V(L.x, L.y, L.z); };
      if (PA.length < 2 || PB.length < 2 || now - PA[PA.length - 1].t > 0.5 || now - PB[PB.length - 1].t > 0.5) return Infinity; let best = Infinity; for (let t = Math.max(now - 0.25, PA[0].t, PB[0].t); t <= now; t += 0.004) best = Math.min(best, at(PA, t).distanceTo(at(PB, t))); return best; }
    // run one scenario: IT and runner motions as functions of TRUE time; runner packets every `step` with arrival delay `delay(k)`
    function run(name, itPos, runPos, step, delay, T0, T1, rtt){
      const it = 'sim-it-' + name, ru = 'sim-ru-' + name; A.poses.delete(it); A.poses.delete(ru); A.clk.delete(ru); A.host.swT = {}; if (rtt != null) a.rtt.set(ru, rtt); else a.rtt.delete(ru);
      const oldIT = [], oldRU = []; const arrivals = [];
      for (let k = 0, ts = T0; ts <= T1; k++, ts += step) arrivals.push({ts, at:ts + delay(k), p:runPos(ts)});
      arrivals.sort((x, y) => x.at - y.at);
      let newBest = Infinity, oldBest = Infinity, ai = 0;
      for (let now = T0; now <= T1 + 0.8; now += 1 / 60){
        a.pushPose(it, now, itPos(now)); if (!oldIT.length || now - oldIT[oldIT.length - 1].t >= 0.02){ const q = itPos(now); oldIT.push({t:now, x:q.x, y:q.y, z:q.z}); }
        while (ai < arrivals.length && arrivals[ai].at <= now){ const r = arrivals[ai++]; a.pushRemote(ru, now, r.ts + 1000, r.p, now); if (!oldRU.length || now > oldRU[oldRU.length - 1].t) oldRU.push({t:now, x:r.p.x, y:r.p.y, z:r.p.z}); }   // sender clock offset by 1000 s on purpose
        const sw = a.sweepPair(it, ru, now, -Infinity); if (sw.d < newBest) newBest = sw.d;
        const od = oldSwept(oldIT, oldRU, now); if (od < oldBest) oldBest = od;
      }
      return {newD:+newBest.toFixed(3), oldD:+oldBest.toFixed(3), newTag:newBest <= reach, oldTag:oldBest <= reach};
    }
    const P = (x, y, z) => new V(x, y, z);
    // A: IT hovers; runner flashes through at 15 m/s; 15 Hz packets arriving 40-260 ms late, unevenly
    res.fastJitter = run('a', t => P(0, 5, 0), t => P(-4 + 15 * (t - 10), 5, 0), 1 / 15, k => 0.04 + 0.22 * ((k * 7919) % 13) / 13, 10, 10.6);
    // B: both moving, head-on through each other (IT +8 m/s, runner -8 m/s), 15 Hz, steady 150 ms delay
    res.headOn = run('b', t => P(-3 + 8 * (t - 20), 5, 0), t => P(3 - 8 * (t - 20), 5, 0), 1 / 15, k => 0.15, 20, 20.8);
    // C: slow, uneven updates like the test browsers (every 0.45 s, 100-400 ms late), crossing between two samples
    res.sparse = run('c', t => P(0, 5, 0), t => P(-2.2 + 5 * (t - 30), 5, 0), 0.45, k => 0.1 + 0.3 * (k % 2), 30, 31.2);
    // D: near miss 1 m to the side, same timing as A: must not tag
    res.nearMiss = run('d', t => P(0, 5, 0), t => P(-4 + 15 * (t - 40), 5, 1.0), 1 / 15, k => 0.04 + 0.22 * ((k * 7919) % 13) / 13, 40, 40.6);
    // E: a teleport-sized jump straight through IT between two packets: history cleared, no tag
    res.teleport = run('e', t => P(0, 5, 0), t => P(t < 50.3 ? -20 : 20, 5, 0), 1 / 15, k => 0.05, 50, 50.6);
    // F: runner packets stop 0.7 s before it reaches IT (stale): no tag from old data
    res.stale = run('f', t => P(0, 5, 0), t => P(-3 + 2 * (t - 60), 5, 0), 1 / 15, k => (k > 3 ? 99 : 0.05), 60, 61.5);
    // G: both flying head-on at 8 m/s with a steady 250 ms one-way delay; the coordinator's ping measured a 500 ms round trip
    res.headOnLag = run('g', t => P(-3 + 8 * (t - 70), 5, 0), t => P(3 - 8 * (t - 70), 5, 0), 1 / 15, k => 0.25, 70, 70.8, 0.5);
    // H: same, but no round-trip measurement yet (worst case: remote placed late by the full delay)
    res.headOnLagNoRtt = run('h', t => P(-3 + 8 * (t - 80), 5, 0), t => P(3 - 8 * (t - 80), 5, 0), 1 / 15, k => 0.25, 80, 80.8);
    // I: sparse straddle: updates every 0.6 s place the runner 2.4 m before and 2.4 m after IT (the crossing is only between samples)
    res.sparseStraddle = run('i', t => P(0, 5, 0), t => P(-2.4 + 8 * (t - 90), 5, 0.1), 0.6, k => 0.15, 90, 91.0);
    // J: same timing, passing 1.5 m to the side: no tag
    res.sparseMiss = run('j', t => P(0, 5, 0), t => P(-2.4 + 8 * (t - 100), 5, 1.5), 0.6, k => 0.15, 100, 101.0);
    // K: crossing paths at right angles, both 8 m/s, reaching the same point at the same TRUE moment; runner data 250 ms late
    res.crossLag = run('k', t => P(-3 + 8 * (t - 110), 5, 0), t => P(0, 5, -3 + 8 * (t - 110)), 1 / 15, k => 0.12, 110, 110.8, 0.24);
    res.crossLagNoRtt = run('l', t => P(-3 + 8 * (t - 120), 5, 0), t => P(0, 5, -3 + 8 * (t - 120)), 1 / 15, k => 0.12, 120, 120.8);
    res.crossLag250 = run('m', t => P(-3 + 8 * (t - 130), 5, 0), t => P(0, 5, -3 + 8 * (t - 130)), 1 / 15, k => 0.25, 130, 130.8, 0.5);
    return res; });
  ok('fast fly-by at 15 m/s, 15 Hz with uneven 40-260 ms delays: tagged by the new sweep', sim.fastJitter.newTag, JSON.stringify(sim.fastJitter));
  ok('head-on crossing while both fly, 150 ms delay: tagged by the new sweep (sender-time alignment)', sim.headOn.newTag, JSON.stringify(sim.headOn));
  ok('sparse uneven updates (every 0.45 s, 100-400 ms late), crossing between samples: tagged', sim.sparse.newTag, JSON.stringify(sim.sparse));
  ok('a 1 m near miss is never a tag', !sim.nearMiss.newTag && sim.nearMiss.newD > 0.9, JSON.stringify(sim.nearMiss));
  ok('a teleport straight through IT is not a tag', !sim.teleport.newTag, JSON.stringify(sim.teleport));
  ok('stale data (packets stop before contact) never tags', !sim.stale.newTag, JSON.stringify(sim.stale));
  ok('head-on at 8 m/s each with 250 ms delay and a measured round trip: tagged', sim.headOnLag.newTag, JSON.stringify(sim.headOnLag));
  out.push('INFO head-on with 250 ms delay but NO round-trip measurement yet: ' + JSON.stringify(sim.headOnLagNoRtt)); console.log(out[out.length - 1]);
  ok('sparse straddle (0.6 s updates, crossing only between samples): tagged by the gap-free sweep', sim.sparseStraddle.newTag, JSON.stringify(sim.sparseStraddle));
  ok('crossing paths, 8 m/s each, runner data 120 ms late (jittery arrival not modelled), round trip measured: tagged (delay compensation)', sim.crossLag.newTag, JSON.stringify(sim.crossLag));
  out.push('INFO crossing paths, 120 ms late, NO round trip measured yet: ' + JSON.stringify(sim.crossLagNoRtt) + ' | 250 ms late (compensation capped at 150 ms): ' + JSON.stringify(sim.crossLag250)); console.log(out[out.length - 1]);
  ok('sparse pass 1.5 m to the side: not tagged', !sim.sparseMiss.newTag, JSON.stringify(sim.sparseMiss));
  out.push('old-v19 sweep on the same cases: ' + JSON.stringify(Object.fromEntries(Object.entries(sim).map(([k, v]) => [k, v.oldTag]))));
  console.log(out[out.length - 1]);
  // refreshed headset Activities panel
  fs.writeFileSync(D + 'panel_activities_v19b.png', Buffer.from((await p.evaluate(() => window.__likeflies.panelImage('Activities'))).split(',')[1], 'base64'));
  fs.writeFileSync(D + 'fix19b.log', 'v0.0.19b focused checks (single browser, SYNTHETIC inputs into the exact built source)\n' + out.join('\n') + '\n' + (errs.length ? errs.join('\n') : 'no page errors'));
  console.log(errs.length ? errs.slice(0, 6).join('\n') : 'no page errors'); await b.close();
})();
