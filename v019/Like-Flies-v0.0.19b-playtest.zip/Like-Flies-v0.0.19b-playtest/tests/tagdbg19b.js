const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const url = 'http://127.0.0.1:8080/index.html?peerhost=127.0.0.1:9000&room=td' + Date.now() % 100000;
  const mk = async n => { const p = await (await b.newContext({viewport:{width:200, height:140}})).newPage(); p.on('pageerror', e => console.log(n, 'ERR', e.message)); await p.goto(url, {timeout:90000}); await p.fill('#mpName', n); await p.dispatchEvent('#mpName', 'input'); return p; };
  const A = await mk('Job'); await A.waitForTimeout(5000); const B = await mk('Sage');
  for (let i = 0; i < 40; i++){ if (await B.evaluate(() => window.__likeflies.net.remotes.size >= 1)) break; await B.waitForTimeout(1000); }
  for (const p of [A, B]){ await p.click('#flatBtn'); await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; }); }
  const put = (p, pt) => p.evaluate(pt => { const L = window.__likeflies, V = THREE.Vector3, h = new V(); L.game.crawl = null; L.game.level = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); L.camera.getWorldPosition(h); L.rig.position.add(new V(pt[0] - h.x, pt[1] - h.y, pt[2] - h.z)); }, pt);
  await put(A, [20, 8, 30]); await put(B, [22, 8, 30]);
  await A.evaluate(() => window.__likeflies.act.join()); await B.evaluate(() => window.__likeflies.act.join()); await A.waitForTimeout(4000);
  await put(B, [20, 8, 30]); await A.waitForTimeout(2500);
  const samples = []; for (let k = 0; k < 8; k++){ samples.push(await A.evaluate(() => { const L = window.__likeflies, A = L.act.ACT, now = L.now(); const r = [...L.net.remotes.values()][0]; let thrown = null; try{ L.act.tick(0.016, now); }catch(e){ thrown = e.message; }
      return {recvAge:r ? +(now - r.recv).toFixed(2) : null, on:r && r.on, kind:r && r.kind, out:r && r.out, dd:r && r.dd, isHost:L.act.isHost(), thrown, swT:JSON.stringify(A.host.swT), it:A.snap.names[A.snap.tag.it]}; })); await A.waitForTimeout(250); }
  console.log(JSON.stringify(samples));
  console.log(JSON.stringify(await A.evaluate(() => { const L = window.__likeflies, a = L.act, A = a.ACT, T = A.snap.tag, now = L.now(); const pids = Object.keys(T.mem); const other = pids.find(p => p !== T.it);
    const buf = p => (A.poses.get(p) || []).map(s => [+(now - s.t).toFixed(2), +s.x.toFixed(2), +s.z.toFixed(2)]).slice(-4);
    const sw = other ? a.swept(T.it, other, now, 0.6) : null;
    return {now:+now.toFixed(2), it:T.it && T.it.slice(-5), other:other && other.slice(-5), bufIt:buf(T.it), bufOther:buf(other), clk:[...A.clk].map(([k, v]) => [k.slice(-5), v.length]), rtt:[...A.rtt].map(([k, v]) => [k.slice(-5), +v.toFixed(3)]), swT:A.host.swT, rdyIn:+(A.host.rdyUntil - now).toFixed(2), sw:sw && {d:String(sw.d), stale:!!sw.stale, empty:!!sw.empty, t1:sw.t1 && +(now - sw.t1).toFixed(2)}, elig:pids.map(p => a.ACT && p.slice(-5)), events:A.events.slice(-5)}; }), null, 0));
  await b.close(); })();
