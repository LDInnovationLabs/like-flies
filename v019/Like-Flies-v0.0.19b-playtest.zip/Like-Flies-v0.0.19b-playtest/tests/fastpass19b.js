// v0.0.19b ONE live two-browser check (REAL local peer connection, desktop Chromium, software WebGL): the runner flies
// straight through IT in about half a second (test-only: positions set in steps, gravity 0). No hold-contact fallback.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
  const url = 'http://127.0.0.1:8080/index.html?peerhost=127.0.0.1:9000&room=fp' + Date.now() % 100000, T0 = Date.now(), out = [];
  const ok = (n, c, d) => { const l = (c ? 'PASS ' : 'FAIL ') + n + (d ? '  ' + d : '') + '  [' + Math.round((Date.now() - T0) / 1000) + 's]'; out.push(l); console.log(l); };
  const mk = async (n, w, h) => { const p = await (await b.newContext({viewport:{width:w, height:h}})).newPage(); await p.goto(url, {timeout:60000}); await p.fill('#mpName', n); await p.dispatchEvent('#mpName', 'input'); return p; };
  const until = async (p, fn, arg, ms) => { for (let t = 0; t < ms; t += 300){ if (await p.evaluate(fn, arg)) return true; await p.waitForTimeout(300); } return false; };
  const A = await mk('Job', 240, 160); await A.waitForTimeout(4000); const B = await mk('Sage', 480, 320);
  await until(B, () => window.__likeflies.net.remotes.size >= 1, null, 40000);
  for (const p of [A, B]){ await p.click('#flatBtn'); await p.evaluate(() => { const t = window.__likeflies.tune(); t.gravity = 0; t.bots = 0; t.rtOn = 0; }); }
  const put = (p, pt) => p.evaluate(pt => { const L = window.__likeflies, V = THREE.Vector3, h = new V(); L.game.crawl = null; L.game.level = null; L.game.stickCool = 1e12; L.rig.quaternion.identity(); L.rig.updateMatrixWorld(true); L.camera.getWorldPosition(h); L.rig.position.add(new V(pt[0] - h.x, pt[1] - h.y, pt[2] - h.z)); }, pt);
  await put(A, [20, 8, 30]); await put(B, [24, 8, 30]);
  await A.evaluate(() => window.__likeflies.act.join()); await B.evaluate(() => window.__likeflies.act.join());
  const agreed = await until(B, () => { const S = window.__likeflies.act.ACT.snap; return !!S.tag.it && S.rev > 0; }, null, 15000);
  const sA = await A.evaluate(() => ({rev:window.__likeflies.act.ACT.snap.rev, it:window.__likeflies.act.ACT.snap.names[window.__likeflies.act.ACT.snap.tag.it]})), sB = await B.evaluate(() => ({rev:window.__likeflies.act.ACT.snap.rev, it:window.__likeflies.act.ACT.snap.names[window.__likeflies.act.ACT.snap.tag.it], ev:window.__likeflies.act.ACT.events.filter(e => /snap/.test(e.k)).length}));
  ok('Sage adopts the coordinator\'s snapshots under the new authority check (late join to Tag)', agreed && sB.it === sA.it, JSON.stringify({A:sA, B:sB}));
  const itIsJob = sA.it === 'Job', IT = itIsJob ? A : B, RUN = itIsJob ? B : A;
  await IT.waitForTimeout(2600);                                              // past the 2 s get-ready window
  const ip = await IT.evaluate(() => { const h = new THREE.Vector3(); window.__likeflies.camera.getWorldPosition(h); return h.toArray(); });
  await put(RUN, [ip[0] - 3, ip[1], ip[2] + 0.05]); await RUN.waitForTimeout(1200);  // settle (the start position is a jump, it clears history)
  const t0 = Date.now(); for (let k = 0; k <= 12; k++){ await put(RUN, [ip[0] - 3 + k * 0.5, ip[1], ip[2] + 0.05]); await RUN.waitForTimeout(25); }
  const crossMs = Date.now() - t0; await put(RUN, [ip[0] + 6, ip[1], ip[2] + 0.05]);  // keep going away: no holding contact
  const moved = await until(A, it => { const S = window.__likeflies.act.ACT.snap; return S.names[S.tag.it] !== it; }, sA.it, 6000);
  const fin = await A.evaluate(() => { const A = window.__likeflies.act.ACT, S = A.snap; return {it:S.names[S.tag.it], pas:Object.fromEntries(Object.entries(S.tag.pas).map(([k, v]) => [S.names[k], v])), tagEv:A.events.filter(e => /tag/.test(e.k)), rtt:[...window.__likeflies.act.rtt.values()].map(v => +v.toFixed(3))}; });
  ok('a straight fly-through in ~' + crossMs + ' ms (no holding) transfers IT once, +1 pass', moved && fin.pas[sA.it] === 1, (itIsJob ? 'runner Sage = remote at the coordinator' : 'runner Job = the coordinator itself') + ' ' + JSON.stringify(fin));
  await B.screenshot({path:__dirname + '/s19b/fastpass_sage_view.png'});
  fs.writeFileSync(__dirname + '/s19b/fastpass19b.log', out.join('\n')); await b.close(); })();
